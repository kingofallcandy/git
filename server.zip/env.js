module.exports = {
  devServer: {
    host: 'localhost',
    port: 3000
  }
};
